package agendacompleta;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;


public class ABCC extends MIDlet implements CommandListener {
    Alert       a;
    Command     c;
    Command     ver, nuevo, inicio, guardar, borrar;
    Display     d;
    Form        f, ingresar, bor;
    String[]    contacto;
    StringItem  listado;
    TextField   nom, edad, email, tf, br;    
    int         i;
    
    public ABCC() {
        i       = 0;
        d       = Display.getDisplay(this);
        c       = new Command("Salir", Command.EXIT, 3);
        nuevo   = new Command("Nuevo", Command.SCREEN, 2);
        guardar = new Command("Guardar", Command.SCREEN, 2);
        inicio  = new Command("Regresar", Command.SCREEN, 3);
        //borrar  = new Command("Borrar", Command.SCREEN, 3);
        
        f           = new Form("Mi Agenda");
        ingresar    = new Form("Nuevo Contacto");
        //bor = new Form("Borrar");
        
        nom     = new TextField("Nombre: ", "", 30, TextField.ANY);
        edad    = new TextField("Edad: ", "", 30, TextField.NUMERIC);
        email   = new TextField("Correo: ", "", 30, TextField.EMAILADDR);
        tf      = new TextField("Telefono: ", "", 30, TextField.NUMERIC);
        //br = new TextField("Qué registro desea borrar (ingrese el número)","",30,TextField.NUMERIC);
        
        //bor.append(br);
        //bor.addCommand(inicio);
        ingresar.addCommand(inicio);
        ingresar.addCommand(guardar);
        ingresar.append(nom);
        ingresar.append(edad);
        ingresar.append(email);
        ingresar.append(tf);
        ingresar.setCommandListener(this);
        
        listado = new StringItem("", "");
        f.append(listado);
        f.addCommand(c);
        f.addCommand(nuevo);
        //f.addCommand(borrar);
        f.setCommandListener(this);
    }

    public void startApp() throws MIDletStateChangeException {
        mostrar();
        d.setCurrent(f);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }

    public void commandAction(Command co, Displayable di) {
        if(co == nuevo) { d.setCurrent(ingresar); }
        if(co == guardar) {            
            // Se crean en los registros
            RMSOps rmso = new RMSOps();
            rmso.abrir("ZonaJavaZone");
            String name = nom.getString();
            String age = edad.getString();
            String mail = email.getString();
            String phone = tf.getString();
            System.out.println("DATOS: " + name);
            rmso.adicionarRegistro(name);
            rmso.adicionarRegistro(age);
            rmso.adicionarRegistro(mail);
            rmso.adicionarRegistro(phone);
            rmso.cerrar();
            
            a = new Alert("NOTA", "Guardado", null, AlertType.CONFIRMATION);
            a.setTimeout(5000);
            d.setCurrent(a);
            nom.setString("");
            edad.setString("");
            email.setString("");
            tf.setString("");                    
        }
        if(co == inicio) {
            mostrar();
            d.setCurrent(f);
        }
        if(co == borrar) {
            //borrarR();
        }
        
        if(co == c) {
            destroyApp(false);
            notifyDestroyed();
        }
    }
    
    
    public void mostrar() {
        RMSOps mem = new RMSOps();  
        mem.abrir("ZonaJavaZone"); // Se abre el registro
        String[] contactos = mem.listarRegistroS(); // Se obtienen
        int numReg = mem.getNumRecords();
        int i, j = 1;
        String impresion = "";            
        for(i = 1; i < numReg; i+=4) {
            impresion += "\nContacto número " + (j) + "\n";
            impresion += "Nombre:" + contactos[i] + "\n";
            impresion += "Edad:" + contactos[i + 1] + "\n";
            impresion += "Correo:" + contactos[i + 2] + "\n";
            impresion += "Teléfono:" + contactos[i + 3] + "\n";
            //impresion += contactos[i + 1];
            j++;
        }
        listado.setText(impresion);
    }
    
    /*public void borrarR() {
            RMSOps mem = new RMSOps();   
            d.setCurrent(bor);
            String borra = br.getString();
            int x = Integer.parseInt(borra);
            mem.borrar(x);
    }*/
}

