
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/**

 */
public class Agenda extends MIDlet implements CommandListener {
    Command c;
    Command cmdVer,cmdNuevoUsr,cmdInicio,cmdGuardar, cmdIrTB, cmdIrSexo;
    Display d;
    Form formInicio,formData1, formData2, formData3;
    String[] contacto;
    TextField nombre,edad,email,tel;
    List listaGenero;
    TextBox boxDescr;
    int i;
    public Agenda(){
    i=0;
    d=Display.getDisplay(this);
    c=new Command ("Salir",Command.EXIT,3);
    cmdNuevoUsr=new Command("Nuevo Contacto",Command.SCREEN,2);
    cmdGuardar = new Command ("Guardar",Command.SCREEN,2);            
    cmdInicio=new Command("Regresar",Command.SCREEN,3);
    cmdIrSexo = new Command("Siguiente", Command.SCREEN, 2);
    cmdIrTB = new Command("Siguiente", Command.SCREEN, 2);
    
    cmdVer=new Command ("Ver",Command.OK,0);
    formInicio=new Form("Agenda sensual");
    formData1=new Form("Nuevo Contacto");
    nombre=new TextField("Nombre","",30,TextField.ANY);
    edad=new TextField("Edad","",30,TextField.NUMERIC);
    email=new TextField("Email","",30,TextField.EMAILADDR);
    tel = new TextField("Telefono","",30,TextField.NUMERIC);
    listaGenero = new List("Genero", List.EXCLUSIVE);
    boxDescr = new TextBox("Descripcion", "", 50, TextField.ANY);
    
    //////Menu//////
    formData1.addCommand(cmdIrSexo);
    formData1.append(nombre);
    formData1.append(edad);
    formData1.append(email);    
    ////////////////////////////////////
    formData1.setCommandListener(this);
    formInicio.addCommand(cmdVer);
    formInicio.addCommand(c);
    formInicio.addCommand(cmdNuevoUsr);
    formInicio.setCommandListener(this);
    //////////////////////////////////
    listaGenero.append("Hombre", null);
    listaGenero.append("Mujer", null);
    listaGenero.append("Otro", null);
    listaGenero.addCommand(cmdIrTB);
    listaGenero.setCommandListener(this);
    ///////////////////////////////////
    boxDescr.addCommand(cmdGuardar);
    boxDescr.setCommandListener(this);
    boxDescr.addCommand(cmdInicio);
    }
   
    public void startApp() throws MIDletStateChangeException  {
        d.setCurrent(formInicio);
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
        
    }

    public void commandAction(Command co, Displayable di) 
        {
            if(co==cmdNuevoUsr)
                {
                    d.setCurrent(formData1);
                }
            if(co == cmdIrSexo)
                {
                    d.setCurrent(listaGenero);
                }
            if(co == cmdIrTB)
                {
                    d.setCurrent(boxDescr);
                }
            if(co==cmdGuardar)
                {
                    Alert a=new Alert("","contacto\nguardado",null,AlertType.INFO);
                    d.setCurrent(a);
                    a.setTimeout(2000);
                }
            if(co==cmdInicio)
                {
                    StringItem si = new StringItem("","Nombre:"+nombre.getString()+"\nEdad:"+edad.getString()+"\nEmail:"+email.getString()+"\n"
                            + "Telefono: " + tel.getString()+ "\n" + "Sexo: \n" + listaGenero.getString(listaGenero.getSelectedIndex()) + "\n" + "Descripcion " + 
                            boxDescr.getString() + "\n");
                    formInicio.append(si);
                    d.setCurrent(formInicio);
                }
            if(co==c)
                {
                    destroyApp(false);
                    notifyDestroyed();
                }
       }
    }

